import React from 'react';

const Timer = (props) => (
  useEffect(() => {
    const timer = setInterval(() => {
      console.log("타이머 돌아가는중...");
    }, 1000);
  }, []);
  );

export default Timer;