import React, { useState } from "react";

const CleanUp = () => {
  const [buttonName, setButtonName] = useState(false);

  const handleButtonNmae = () => {
    setButtonName(buttonName);
  };

  return <button onClick={handleButtonNmae}>{`Timer ${buttonName}`}</button>;
};

export default CleanUp;
